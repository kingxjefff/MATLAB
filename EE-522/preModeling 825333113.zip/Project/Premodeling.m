 close all; clc;
L = 180e-6;   % 100.8uH
R = 40;        % 100Ohms
C = 150e-6;      % 10uF
Vref = 15;      % 10V
Vin = 6;       % 24V
dc = 0.5;
plot(out)